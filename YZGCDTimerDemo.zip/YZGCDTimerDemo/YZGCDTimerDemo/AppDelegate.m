//
//  AppDelegate.m
//  YZGCDTimerDemo
//
//  Created by 韩云智 on 2017/3/7.
//  Copyright © 2017年 韩云智. All rights reserved.
//

#import "AppDelegate.h"
#import "YZTimer.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (void)applicationDidBecomeActive:(UIApplication *)application
{
    NSLog(@"---applicationDidBecomeActive----");
    // 进入前台
    [YZTimer yz_reload];
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    NSLog(@"---applicationDidEnterBackground----");
    // 进入后台
    [YZTimer yz_background];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
