//
//  YZTimer.m
//  YZGCDTimerDemo
//
//  Created by 韩云智 on 2017/3/7.
//  Copyright © 2017年 韩云智. All rights reserved.
//

#import "YZTimer.h"

@interface YZTimer ()

@property (nonatomic, strong) dispatch_source_t timer;
@property (nonatomic, strong) NSMutableArray * timerArr;
@property (nonatomic, strong) NSMutableArray * backgroundArr;
@property (nonatomic, assign) BOOL isRun;

@end

@implementation YZTimer

//单例
+ (YZTimer *)sharedManager{
    static YZTimer * sharedYZTimer = nil;
    static dispatch_once_t predicateRoot;
    dispatch_once(&predicateRoot, ^{
        sharedYZTimer = [[self alloc] init];
    });
    return sharedYZTimer;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        _isRun = NO;
        _timerArr = [NSMutableArray new];
        _backgroundArr = [NSMutableArray new];
        [self upTimer];
    }
    return self;
}

- (void)upTimer{
    double delayInSeconds = 1.0;
    _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0));
    dispatch_source_set_timer(_timer, DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC, 0.0);
    dispatch_source_set_event_handler(_timer, ^{
        [self yz_refresh];
    });
}

- (void)yz_refresh{
    for (id value in _timerArr) {
        if ([value respondsToSelector:@selector(yz_refresh)]) {
            [value performSelector:@selector(yz_refresh)];
        }
    }
}

+ (void)yz_reload{
    YZTimer * manager = [self sharedManager];
    for (id value in manager.timerArr) {
        if ([value respondsToSelector:@selector(yz_reload)]) {
            [value performSelector:@selector(yz_reload)];
        }
    }
    if (!manager.isRun && manager.timerArr.count > 0) {
        manager.isRun = YES;
        dispatch_resume(manager.timer);
    }
    for (id value in manager.backgroundArr) {
        if ([value respondsToSelector:@selector(yz_reload)]) {
            [value performSelector:@selector(yz_reload)];
        }
    }
}

+ (void)yz_background{
    YZTimer * manager = [self sharedManager];
    if (manager.isRun) {
        dispatch_suspend(manager.timer);
        manager.isRun = NO;
    }
    for (id value in manager.timerArr) {
        if ([value respondsToSelector:@selector(yz_background)]) {
            [value performSelector:@selector(yz_background)];
        }
    }
    for (id value in manager.backgroundArr) {
        if ([value respondsToSelector:@selector(yz_background)]) {
            [value performSelector:@selector(yz_background)];
        }
    }
}

+ (void)addTimer:(id)object{
    YZTimer * manager = [self sharedManager];
    [manager.timerArr addObject:object];
    if (!manager.isRun) {
        manager.isRun = YES;
        dispatch_resume(manager.timer);
    }
}

+ (void)removeTimer:(id)object{
    YZTimer * manager = [self sharedManager];
    [manager.timerArr removeObject:object];
    if (manager.timerArr.count == 0) {
        dispatch_suspend(manager.timer);
        manager.isRun = NO;
    }
}

+ (void)addBackground:(id)object{
    [[self sharedManager].backgroundArr addObject:object];
}

+ (void)removeBackground:(id)object{
    [[self sharedManager].backgroundArr removeObject:object];
}

@end
