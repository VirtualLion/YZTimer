//
//  ViewController.m
//  YZGCDTimerDemo
//
//  Created by 韩云智 on 2017/3/7.
//  Copyright © 2017年 韩云智. All rights reserved.
//

#import "ViewController.h"
#import "YZTimer.h"

@interface ViewController ()

@end

@implementation ViewController{
    NSInteger _i;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    _i = 0;
    [YZTimer addTimer:self];
}

- (void)yz_refresh{
    NSLog(@"timer %@",@(_i++));
}

- (void)yz_reload{
    _i = 100;
    NSLog(@"------ 100 ------");
}

- (void)yz_background{
    _i = 0;
    NSLog(@"------ 0 ------");
}

@end
