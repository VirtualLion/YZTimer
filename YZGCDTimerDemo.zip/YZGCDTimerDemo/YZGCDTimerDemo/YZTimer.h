//
//  YZTimer.h
//  YZGCDTimerDemo
//
//  Created by 韩云智 on 2017/3/7.
//  Copyright © 2017年 韩云智. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YZTimer : NSObject

+ (void)addTimer:(id)object;
+ (void)removeTimer:(id)object;

+ (void)addBackground:(id)object;
+ (void)removeBackground:(id)object;

+ (void)yz_reload;
+ (void)yz_background;

@end
